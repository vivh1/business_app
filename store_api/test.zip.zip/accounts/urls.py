from django.urls import include, path
from . import views

urlpatterns = [
    path('login/', views.login_api, name='login_api'),
    path('logout/', views.logout_api, name='logout_api'),
    path('register/', views.register_api, name='register_api'),
    path('profile/', views.profile_api, name='profile_api'),
    path('users/',views.users_api, name='users_api'),
    path('update/',views.update_api,name='update_api'),
    path('users/<int:user_id>/', views.delete_user_api, name='delete-user'),
]