"""
URL configuration for store_api project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from .views import home, frontend
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # All accounts-related API (login, logout, profile) under /api/
    path('api/', include('accounts.urls')),

    path('api/', include('products.urls')),

    path('api/', include('cart.urls')),

    path('api/', include('orders.urls')),

    # home test endpoint after login
    path('home/', home),

    path("", frontend),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
